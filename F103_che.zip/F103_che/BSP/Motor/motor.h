#ifndef motor_h
#define motor_h

#include "main.h"
#include "bsp.h"

#define PWMA TIM4->CCR3	//����		���Ĵ���������
#define PWMB TIM4->CCR4	//�ҵ��

#define AIN1_0 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_RESET)//����
#define AIN1_1 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET)

#define AIN2_0 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET)
#define AIN2_1 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_SET)

#define BIN1_0 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET)//�ҵ��
#define BIN1_1 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET)

#define BIN2_0 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET)
#define BIN2_1 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET)

extern long motor1,motor2;
extern u8 stop_flag;//���������ֹͣλ

void set_pwm(int motor1,int motor2);
void xianfu_pwm(void);
u8 turnoff_motor(float pitch);
int read_speed(int TIMx);
//void forward();
//void turn_left();
//void turn_right();
//void back();



#endif
